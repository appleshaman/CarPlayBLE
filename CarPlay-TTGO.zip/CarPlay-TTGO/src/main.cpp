#include <Arduino.h>
#include <TFT_eSPI.h>
TFT_eSPI tft = TFT_eSPI();
void setup() {
  // put your setup code here, to run once:
 tft.init();
 tft.setRotation(1);
 tft.fillScreen(0x38b25c); // 0x38b25c
}

void loop() {
  // put your main code here, to run repeatedly:

}
